# RaspberryPiFoundationProject

TEAM NAME		- BIRDS AREN'T REAL

TEAM LEADER		- LUKE HENZELL

TEAM TESTER		- LUKE CAMPBELL

LEAD DEVELOPER	- ASHFORD RENNIE

A project teaching how to turn a previously created deck of cards into something that can be used in a game.

This project will specifcally teach the student how to apply values to and how to influence objects using Object Oriented Programming. 

The 'Step By Step' folder includes step by step instructions with examples of where the student should be at the start and the end of each step.

The 'Final Project Presentation' folder includes a copy of the original Raspberry Pi Foundation Project in its completed form, a completed form of our project, and a .pdf guide of all included steps. An included sample code area is at the bottom to demonstrate functionality taught in the project.